# 大模型知识编辑实验项目运行说明

## 1. 项目内容

本项目完成 Knowledge Editing for LLMs 实验的四个任务：

- `baseline.py`：Task 1，未编辑模型的基线测试。
- `edit_rome.py`：Task 2，使用 ROME 进行 10 条单事实编辑。
- `edit_memit.py`：Task 3，使用 MEMIT 进行 500 条批量编辑。
- `evaluate.py`：Task 4，汇总 ES、PS、NS 指标并生成评估结果。

辅助文件：

- `requirements.txt`：Python 依赖。
- `data/`：Baseline 自定义事实数据和 CounterFact 500 条数据。
- `hparams/`：ROME 和 MEMIT 的 EasyEdit 参数配置。
- `outputs/`：实验输出结果。
- `reports/`：实验报告。

## 2. 环境准备

实验使用 Python 3.10 和支持 CUDA 的 PyTorch 环境运行 ROME/MEMIT：

```powershell
conda create -n easyedit python=3.10 -y
conda activate easyedit
pip install -r requirements.txt
```

ROME 和 MEMIT 依赖 EasyEdit。本项目脚本会优先从 `external/EasyEdit` 导入 EasyEdit；如果该目录不存在，请先执行：

```powershell
git clone https://github.com/zjunlp/EasyEdit.git external/EasyEdit
```

## 3. 运行 Task 1：Baseline

```powershell
python baseline.py
```

输出文件会保存到：

- `outputs/baseline_*.json`
- `outputs/baseline_*.csv`

## 4. 运行 Task 2：ROME

```powershell
python edit_rome.py --device 0
```

ROME 使用 `data/baseline_facts.json` 中的 10 条事实逐条编辑，并在每条编辑后恢复原模型权重。

## 5. 运行 Task 3：MEMIT

如果需要重新准备 CounterFact 500 条数据：

```powershell
python edit_memit.py --prepare-data
```

执行完整 500 条批量编辑与评估：

```powershell
python edit_memit.py --device 0 --eval-limit 500
```

输出文件会保存到：

- `outputs/memit_*.json`
- `outputs/memit_*.csv`

## 6. 运行 Task 4：综合评估

```powershell
python evaluate.py
```

`evaluate.py` 会自动选择可用结果中评估条数最多的 Baseline、ROME、MEMIT 输出，并生成：

- `outputs/evaluation_summary_*.json`
- `outputs/evaluation_summary_*.csv`
- `outputs/evaluation_summary_*.md`
- `outputs/task4_report.md`


## 7. 已完成结果摘要

当前综合评估结果如下：

| 方法 | 编辑条数 | 评估条数 | ES | PS | NS |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline | 0 | 10 | 1/10 (10.00%) | 0/10 (0.00%) | 6/10 (60.00%) |
| ROME | 10 | 10 | 10/10 (100.00%) | 6/10 (60.00%) | 5/10 (50.00%) |
| MEMIT | 500 | 500 | 480/500 (96.00%) | 247/500 (49.40%) | 485/500 (97.00%) |
