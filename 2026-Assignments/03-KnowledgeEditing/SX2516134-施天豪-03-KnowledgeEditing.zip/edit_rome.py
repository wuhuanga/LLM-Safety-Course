"""Single-fact ROME editing script for Task 2.

The script uses EasyEdit's ROME implementation to edit each fact from the
Task 1 dataset independently. After every edit, the changed weights are restored
before moving to the next fact, so every case starts from the original model.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import importlib.util
import json
import re
import sys
import time
import unicodedata
import warnings
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=FutureWarning, module="transformers")
warnings.filterwarnings("ignore", category=FutureWarning, module="huggingface_hub")


DEFAULT_MODEL = "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_DATA_PATH = Path("data/baseline_facts.json")
DEFAULT_HPARAMS_PATH = Path("hparams/ROME/qwen2.5-0.5b.yaml")
DEFAULT_OUTPUT_DIR = Path("outputs")
PROJECT_ROOT = Path(__file__).resolve().parent
LOCAL_EASYEDIT_PATH = PROJECT_ROOT / "external" / "EasyEdit"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run independent ROME edits with EasyEdit for Task 2."
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Hugging Face model id or local path. Default: {DEFAULT_MODEL}",
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=DEFAULT_DATA_PATH,
        help=f"Task 1 JSON dataset path. Default: {DEFAULT_DATA_PATH}",
    )
    parser.add_argument(
        "--hparams",
        type=Path,
        default=DEFAULT_HPARAMS_PATH,
        help=f"EasyEdit ROME hparams YAML. Default: {DEFAULT_HPARAMS_PATH}",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Directory for ROME outputs. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--device",
        default="0",
        help="CUDA device index, for example 0 or cuda:0. Default: 0",
    )
    parser.add_argument(
        "--max-new-tokens",
        type=int,
        default=32,
        help="Maximum generated tokens for verification. Default: 32",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
        help="Sampling temperature. 0 uses greedy decoding. Default: 0",
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=0.9,
        help="Top-p value used only when temperature > 0. Default: 0.9",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional limit for quick smoke tests.",
    )
    parser.add_argument(
        "--fp16",
        action="store_true",
        help="Load the model in float16 through EasyEdit hparams.",
    )
    parser.add_argument(
        "--rome-layer",
        type=int,
        default=None,
        help="Override the ROME edit layer in the hparams file.",
    )
    parser.add_argument(
        "--v-loss-layer",
        type=int,
        default=None,
        help="Override the ROME optimization loss layer in the hparams file.",
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Record per-case errors and continue instead of stopping.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate files and dataset fields without importing EasyEdit or torch.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show Transformers/EasyEdit logs and warnings.",
    )
    return parser.parse_args()


def configure_stdio() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def aliases_for(record: dict[str, Any], field: str) -> list[str]:
    values = []
    value = record.get(field)
    aliases = record.get(f"aliases_{field}", [])
    if isinstance(value, str):
        values.append(value)
    if isinstance(aliases, list):
        values.extend(str(alias) for alias in aliases)
    return values


def contains_any(answer: str, candidates: list[str]) -> bool:
    normalized_answer = normalize_text(answer)
    return any(normalize_text(candidate) in normalized_answer for candidate in candidates)


def load_dataset(path: Path, limit: int | None) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("Dataset must be a JSON list.")

    required = {
        "prompt",
        "subject",
        "target_new",
        "ground_truth",
        "rephrase_prompt",
        "locality_prompt",
        "locality_ground_truth",
    }
    for index, record in enumerate(data, start=1):
        missing = required - set(record)
        if missing:
            raise ValueError(f"Record {index} is missing fields: {sorted(missing)}")
        if record["subject"] not in record["prompt"]:
            raise ValueError(
                f"Record {index} subject must appear in prompt for ROME: "
                f"{record['subject']} not in {record['prompt']}"
            )

    return data[:limit] if limit else data


def parse_cuda_index(device_arg: str) -> int:
    cleaned = device_arg.lower().replace("cuda:", "").strip()
    if not cleaned.isdigit():
        raise ValueError("--device must be a CUDA index like 0 or cuda:0")
    return int(cleaned)


def add_local_easyedit_to_path() -> None:
    if importlib.util.find_spec("easyeditor") is not None:
        return
    if (LOCAL_EASYEDIT_PATH / "easyeditor").exists():
        sys.path.insert(0, str(LOCAL_EASYEDIT_PATH))


def import_easyedit() -> tuple[Any, Any]:
    add_local_easyedit_to_path()
    try:
        easyeditor = importlib.import_module("easyeditor")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "EasyEdit is not importable. Keep the cloned EasyEdit source at "
            "external/EasyEdit or add it to PYTHONPATH, then install the "
            "dependencies from requirements.txt."
        ) from exc

    try:
        return easyeditor.ROMEHyperParams, easyeditor.BaseEditor
    except AttributeError as exc:
        raise RuntimeError(
            "The installed easyeditor package does not expose ROMEHyperParams "
            "and BaseEditor. Please install/update zjunlp/EasyEdit."
        ) from exc


def ensure_easyedit_available() -> None:
    add_local_easyedit_to_path()
    if importlib.util.find_spec("easyeditor") is None:
        raise ModuleNotFoundError(
            "EasyEdit is not importable. Keep the cloned EasyEdit source at "
            "external/EasyEdit or add it to PYTHONPATH, then install the "
            "dependencies from requirements.txt."
        )


def configure_hparams(
    hparams_cls: Any,
    hparams_path: Path,
    model_name: str,
    device_index: int,
    fp16: bool,
    rome_layer: int | None,
    v_loss_layer: int | None,
) -> Any:
    if not hparams_path.exists():
        raise FileNotFoundError(f"ROME hparams file not found: {hparams_path}")

    hparams = hparams_cls.from_hparams(str(hparams_path))
    hparams.model_name = model_name
    hparams.device = device_index
    hparams.fp16 = fp16
    hparams.model_parallel = False
    if rome_layer is not None:
        hparams.layers = [rome_layer]
    if v_loss_layer is not None:
        hparams.v_loss_layer = v_loss_layer
    return hparams


def ensure_cuda(torch: Any, device_index: int) -> None:
    if not torch.cuda.is_available():
        raise RuntimeError(
            "EasyEdit's ROME implementation expects CUDA. "
            "Install a working CUDA PyTorch build or run on a machine with GPU."
        )
    if device_index >= torch.cuda.device_count():
        raise RuntimeError(
            f"CUDA device {device_index} is not available. "
            f"Visible device count: {torch.cuda.device_count()}"
        )


def generation_kwargs(
    tokenizer: Any,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "max_new_tokens": max_new_tokens,
        "pad_token_id": tokenizer.pad_token_id or tokenizer.eos_token_id,
        "eos_token_id": tokenizer.eos_token_id,
    }
    if temperature > 0:
        kwargs.update({"do_sample": True, "temperature": temperature, "top_p": top_p})
    else:
        kwargs.update(
            {"do_sample": False, "temperature": None, "top_p": None, "top_k": None}
        )
    return kwargs


def generate_answer(
    torch: Any,
    model: Any,
    tokenizer: Any,
    prompt: str,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
) -> str:
    device = next(model.parameters()).device
    encoded = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.inference_mode():
        output_ids = model.generate(
            **encoded,
            **generation_kwargs(tokenizer, max_new_tokens, temperature, top_p),
        )
    new_tokens = output_ids[0, encoded["input_ids"].shape[-1] :]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def build_easyedit_request(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "prompt": record["prompt"],
        "subject": record["subject"],
        "target_new": record["target_new"],
        "ground_truth": record["ground_truth"],
        "rephrase_prompt": record["rephrase_prompt"],
        "locality": {
            "neighborhood": {
                "prompt": record["locality_prompt"],
                "ground_truth": record["locality_ground_truth"],
            }
        },
        "portability": {},
    }


def restore_original_weights(torch: Any, model: Any, weights_copy: dict[str, Any]) -> None:
    if not weights_copy:
        return
    named_parameters = dict(model.named_parameters())
    with torch.no_grad():
        for name, original_value in weights_copy.items():
            if name not in named_parameters:
                raise KeyError(f"Edited parameter not found during restore: {name}")
            parameter = named_parameters[name]
            parameter[...] = original_value.to(device=parameter.device, dtype=parameter.dtype)


def jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if hasattr(value, "detach"):
        value = value.detach().cpu()
    if hasattr(value, "tolist"):
        return value.tolist()
    if hasattr(value, "item"):
        return value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def evaluate_after_edit(
    args: argparse.Namespace,
    torch: Any,
    editor: Any,
    record: dict[str, Any],
    case_id: int,
) -> dict[str, Any]:
    target_aliases = aliases_for(record, "target_new")
    locality_aliases = aliases_for(record, "locality_ground_truth")

    pre_direct_answer = generate_answer(
        torch,
        editor.model,
        editor.tok,
        record["prompt"],
        args.max_new_tokens,
        args.temperature,
        args.top_p,
    )
    pre_rephrase_answer = generate_answer(
        torch,
        editor.model,
        editor.tok,
        record["rephrase_prompt"],
        args.max_new_tokens,
        args.temperature,
        args.top_p,
    )
    pre_locality_answer = generate_answer(
        torch,
        editor.model,
        editor.tok,
        record["locality_prompt"],
        args.max_new_tokens,
        args.temperature,
        args.top_p,
    )

    request = build_easyedit_request(record)
    cuda_device = torch.device(f"cuda:{editor.hparams.device}")
    torch.cuda.reset_peak_memory_stats(cuda_device)
    start = time.perf_counter()
    edited_model, weights_copy = editor.apply_algo(
        editor.model,
        editor.tok,
        [request],
        editor.hparams,
        copy=False,
        return_orig_weights=True,
        keep_original_weight=False,
    )
    elapsed = time.perf_counter() - start
    peak_memory_mb = torch.cuda.max_memory_allocated(cuda_device) / (1024**2)

    try:
        post_direct_answer = generate_answer(
            torch,
            edited_model,
            editor.tok,
            record["prompt"],
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        post_rephrase_answer = generate_answer(
            torch,
            edited_model,
            editor.tok,
            record["rephrase_prompt"],
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        post_locality_answer = generate_answer(
            torch,
            edited_model,
            editor.tok,
            record["locality_prompt"],
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
    finally:
        restore_original_weights(torch, editor.model, weights_copy)
        torch.cuda.empty_cache()

    return {
        "case_id": case_id,
        "subject": record["subject"],
        "prompt": record["prompt"],
        "target_new": record["target_new"],
        "ground_truth": record["ground_truth"],
        "rephrase_prompt": record["rephrase_prompt"],
        "locality_prompt": record["locality_prompt"],
        "locality_ground_truth": record["locality_ground_truth"],
        "pre_direct_answer": pre_direct_answer,
        "pre_rephrase_answer": pre_rephrase_answer,
        "pre_locality_answer": pre_locality_answer,
        "post_direct_answer": post_direct_answer,
        "post_rephrase_answer": post_rephrase_answer,
        "post_locality_answer": post_locality_answer,
        "efficacy_success": contains_any(post_direct_answer, target_aliases),
        "generalization_success": contains_any(post_rephrase_answer, target_aliases),
        "locality_success": contains_any(post_locality_answer, locality_aliases),
        "edit_time_seconds": round(elapsed, 4),
        "max_cuda_memory_mb": round(peak_memory_mb, 2),
    }


def write_outputs(
    results: list[dict[str, Any]],
    output_dir: Path,
    model_name: str,
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_model = re.sub(r"[^A-Za-z0-9_.-]+", "_", model_name).strip("_")
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    json_path = output_dir / f"rome_{safe_model}_{timestamp}.json"
    csv_path = output_dir / f"rome_{safe_model}_{timestamp}.csv"

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(jsonable(results), f, ensure_ascii=False, indent=2)

    fieldnames = [
        "case_id",
        "subject",
        "prompt",
        "target_new",
        "ground_truth",
        "post_direct_answer",
        "efficacy_success",
        "rephrase_prompt",
        "post_rephrase_answer",
        "generalization_success",
        "locality_prompt",
        "locality_ground_truth",
        "post_locality_answer",
        "locality_success",
        "edit_time_seconds",
        "max_cuda_memory_mb",
        "error",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    return json_path, csv_path


def bool_count(results: list[dict[str, Any]], key: str) -> int:
    return sum(1 for result in results if result.get(key) is True)


def print_summary(results: list[dict[str, Any]], json_path: Path, csv_path: Path) -> None:
    completed = [result for result in results if "error" not in result]
    total = len(completed)
    failures = len(results) - total

    print("\nROME summary")
    print(f"- Completed edits: {total}/{len(results)}")
    if failures:
        print(f"- Failed edits: {failures}/{len(results)}")
    if total:
        print(f"- Efficacy success: {bool_count(completed, 'efficacy_success')}/{total}")
        print(
            "- Generalization success: "
            f"{bool_count(completed, 'generalization_success')}/{total}"
        )
        print(f"- Locality success: {bool_count(completed, 'locality_success')}/{total}")
    print(f"- JSON output: {json_path}")
    print(f"- CSV output: {csv_path}\n")

    for result in results:
        prefix = f"[{result['case_id']}] {result.get('subject', '')}"
        if "error" in result:
            print(f"{prefix} ERROR: {result['error']}")
            continue
        print(f"{prefix}: {result['prompt']}")
        print(f"    target_new: {result['target_new']}")
        print(f"    post_direct_answer: {result['post_direct_answer']}")
        print(f"    efficacy_success: {result['efficacy_success']}")


def dry_run(args: argparse.Namespace) -> None:
    data = load_dataset(args.data, args.limit)
    if not args.hparams.exists():
        raise FileNotFoundError(f"ROME hparams file not found: {args.hparams}")
    device_index = parse_cuda_index(args.device)
    print("Dry run OK")
    print(f"- Dataset: {args.data} ({len(data)} records)")
    print(f"- Hparams: {args.hparams}")
    print(f"- Model: {args.model}")
    print(f"- CUDA device index: {device_index}")
    print("- EasyEdit and torch were not imported in dry-run mode.")


def main() -> None:
    configure_stdio()
    args = parse_args()

    if args.dry_run:
        dry_run(args)
        return

    if not args.verbose:
        try:
            from transformers.utils import logging as transformers_logging

            transformers_logging.set_verbosity_error()
        except Exception:
            pass

    data = load_dataset(args.data, args.limit)
    device_index = parse_cuda_index(args.device)

    ensure_easyedit_available()
    torch = importlib.import_module("torch")
    ensure_cuda(torch, device_index)
    torch.cuda.set_device(device_index)

    hparams_cls, base_editor_cls = import_easyedit()
    hparams = configure_hparams(
        hparams_cls,
        args.hparams,
        args.model,
        device_index,
        args.fp16,
        args.rome_layer,
        args.v_loss_layer,
    )

    print(f"Loading editor with model: {hparams.model_name}")
    print(f"ROME hparams: {args.hparams}")
    print(f"CUDA device: cuda:{device_index}")
    print(f"Dataset: {args.data} ({len(data)} records)")
    editor = base_editor_cls.from_hparams(hparams)

    results: list[dict[str, Any]] = []
    for case_id, record in enumerate(data, start=1):
        print(
            f"\nEditing {case_id}/{len(data)}: "
            f"{record['subject']} -> {record['target_new']}"
        )
        try:
            result = evaluate_after_edit(args, torch, editor, record, case_id)
            results.append(result)
            print(f"Post answer: {result['post_direct_answer']}")
            print(f"Efficacy success: {result['efficacy_success']}")
        except Exception as exc:
            if not args.continue_on_error:
                raise
            results.append(
                {
                    "case_id": case_id,
                    "subject": record.get("subject"),
                    "prompt": record.get("prompt"),
                    "target_new": record.get("target_new"),
                    "error": repr(exc),
                }
            )
            print(f"ERROR: {exc!r}")
            torch.cuda.empty_cache()

    json_path, csv_path = write_outputs(results, args.output_dir, args.model)
    print_summary(results, json_path, csv_path)


if __name__ == "__main__":
    main()
