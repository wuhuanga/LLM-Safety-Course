# Task 4 综合评估报告

## 评估设置

- Baseline 数据：`outputs\baseline_Qwen_Qwen2.5-0.5B-Instruct_20260521_153100.json`
- ROME 数据：`outputs\rome_Qwen_Qwen2.5-0.5B-Instruct_20260521_153701.json`
- MEMIT 数据：`outputs\memit_Qwen_Qwen2.5-0.5B-Instruct_20260519_183500.json`

## 指标定义

- ES：Efficacy，直接编辑 prompt 是否输出目标新答案。
- PS：Generalization / Paraphrase，改写 prompt 是否仍能输出目标新答案。
- NS：Locality，局部性是否保持。Baseline 和 ROME 使用 locality ground truth 判断；MEMIT 的 CounterFact neighborhood prompt 没有显式 ground truth，因此使用 locality prompt 不泄露 `target_new` 作为局部性近似指标。

## 综合结果

| 方法 | 编辑条数 | 评估条数 | ES | PS | NS | 耗时 | 峰值显存 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Baseline | 0 | 10 | 1/10 (10.00%) | 0/10 (0.00%) | 6/10 (60.00%) | - | - |
| ROME | 10 | 10 | 10/10 (100.00%) | 6/10 (60.00%) | 5/10 (50.00%) | 46.3223s | 3979.62 MB |
| MEMIT | 500 | 500 | 480/500 (96.00%) | 247/500 (49.40%) | 485/500 (97.00%) | 96.1668s | 4363.9 MB |

## 结果分析

Baseline 结果显示，未编辑模型对自定义事实的直接命中率为 10.00%，改写 prompt 命中率为 0.00%，说明 Task 1 数据能够体现模型存在旧知识或知识缺失问题。

ROME 对 10 条自定义事实逐条编辑后，直接编辑成功率为 100.00%，PS 为 60.00%，NS 为 50.00%。这说明单条事实注入有效，但改写泛化和无关事实保持仍有波动。

MEMIT 一次性批量编辑 500 条 CounterFact 数据后，ES 为 96.00%，NS 为 97.00%，说明批量知识注入整体有效且局部性保持较好。PS 为 49.40%，低于 ES，表明同义改写 prompt 下的稳定泛化是主要瓶颈。

## MEMIT 失败案例总结

MEMIT 共 268 条样本未能同时满足 ES、PS、NS 三项指标。失败类型分布如下：

| 失败类型 | 数量 | 说明 |
| --- | ---: | --- |
| PS | 233 | 直接 prompt 成功，但改写 prompt 未输出目标答案，是主要失败来源。 |
| ES,PS | 14 | 直接 prompt 和改写 prompt 都失败，说明该事实编辑不充分。 |
| NS | 9 | locality prompt 中泄露了目标新答案或局部性未保持。 |
| PS,NS | 6 | 改写泛化失败，同时 locality 也受到影响。 |
| ES | 6 | 直接 prompt 未命中。 |

典型失败样例：

| case_id | 失败类型 | subject | target_new |
| ---: | --- | --- | --- |
| 0 | PS | Danielle Darrieux | English |
| 2 | NS | Toko Yasuda | piano |
| 4 | PS | Lyon | Manila |
| 5 | PS,NS | Thomas Joannes Stieltjes | English |
| 6 | PS | Anaal Nathrakh | Philadelphia |

整体来看，MEMIT 在本实验中比 ROME 更适合大规模知识注入。主要不足是 paraphrase prompt 下的泛化能力不足，后续可以通过调整 MEMIT 层范围、增加 covariance 样本量、优化 prompt 模板或使用更强基础模型进行改进。