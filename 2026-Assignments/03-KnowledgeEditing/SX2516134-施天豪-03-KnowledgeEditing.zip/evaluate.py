# -*- coding: utf-8 -*-
"""Comprehensive evaluation for Task 4.

This script aggregates the outputs from baseline.py, edit_rome.py, and
edit_memit.py, then reports ES/PS/NS-style metrics in JSON, CSV, Markdown,
and a Chinese report that can be reused in the final experiment write-up.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any


DEFAULT_OUTPUT_DIR = Path("outputs")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Aggregate Task 1-3 outputs and compute Task 4 metrics."
    )
    parser.add_argument(
        "--baseline",
        type=Path,
        default=None,
        help="Baseline JSON path. Default: latest outputs/baseline_*.json",
    )
    parser.add_argument(
        "--rome",
        type=Path,
        default=None,
        help="ROME JSON path. Default: latest full outputs/rome_*.json",
    )
    parser.add_argument(
        "--memit",
        type=Path,
        default=None,
        help="MEMIT JSON path. Default: latest outputs/memit_*.json",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Directory for evaluation outputs. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--failure-limit",
        type=int,
        default=5,
        help="Maximum failed examples per method to include in Markdown. Default: 5",
    )
    parser.add_argument(
        "--skip-report",
        action="store_true",
        help="Do not generate the Chinese Task 4 report.",
    )
    return parser.parse_args()


def configure_stdio() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def result_record_count(path: Path) -> int:
    try:
        payload = load_json(path)
    except (OSError, json.JSONDecodeError):
        return 0
    if isinstance(payload, list):
        return len([record for record in payload if not isinstance(record, dict) or "error" not in record])
    if isinstance(payload, dict):
        results = payload.get("eval_results")
        if isinstance(results, list):
            return len(results)
        summary = payload.get("summary", {})
        if isinstance(summary, dict):
            try:
                return int(summary.get("edited_requests", 0) or 0)
            except (TypeError, ValueError):
                return 0
    return 0


def latest_file(pattern: str, exclude_tiny: bool = False) -> Path:
    files = list(DEFAULT_OUTPUT_DIR.glob(pattern))
    if exclude_tiny:
        files = [path for path in files if path.stat().st_size > 1000]
    if not files:
        raise FileNotFoundError(f"No files matched {DEFAULT_OUTPUT_DIR / pattern}")
    return max(files, key=lambda path: (result_record_count(path), path.stat().st_mtime))


def resolve_paths(args: argparse.Namespace) -> tuple[Path, Path, Path]:
    baseline = args.baseline or latest_file("baseline_*.json")
    rome = args.rome or latest_file("rome_*.json", exclude_tiny=True)
    memit = args.memit or latest_file("memit_*.json", exclude_tiny=True)
    for path in [baseline, rome, memit]:
        if not path.exists():
            raise FileNotFoundError(path)
    return baseline, rome, memit


def pct(count: int, total: int) -> float:
    return round((count / total * 100), 2) if total else 0.0


def count_true(records: list[dict[str, Any]], key: str) -> int:
    return sum(1 for record in records if record.get(key) is True)


def metric_row(
    method: str,
    source_file: Path,
    edited_records: int,
    evaluated_records: int,
    es_count: int,
    es_total: int,
    ps_count: int,
    ps_total: int,
    ns_count: int,
    ns_total: int,
    edit_time_seconds: float | None = None,
    max_cuda_memory_mb: float | None = None,
    notes: str = "",
) -> dict[str, Any]:
    return {
        "method": method,
        "source_file": str(source_file),
        "edited_records": edited_records,
        "evaluated_records": evaluated_records,
        "ES_count": es_count,
        "ES_total": es_total,
        "ES_percent": pct(es_count, es_total),
        "PS_count": ps_count,
        "PS_total": ps_total,
        "PS_percent": pct(ps_count, ps_total),
        "NS_count": ns_count,
        "NS_total": ns_total,
        "NS_percent": pct(ns_count, ns_total),
        "edit_time_seconds": edit_time_seconds,
        "max_cuda_memory_mb": max_cuda_memory_mb,
        "notes": notes,
    }


def evaluate_baseline(path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    records = load_json(path)
    if not isinstance(records, list):
        raise ValueError(f"Baseline file must contain a list: {path}")
    total = len(records)
    row = metric_row(
        method="Baseline (pre-edit)",
        source_file=path,
        edited_records=0,
        evaluated_records=total,
        es_count=count_true(records, "direct_contains_target_new"),
        es_total=total,
        ps_count=count_true(records, "rephrase_contains_target_new"),
        ps_total=total,
        ns_count=count_true(records, "locality_contains_ground_truth"),
        ns_total=total,
        notes=(
            "Pre-edit reference: ES/PS indicate whether the unedited model already "
            "contains the new target; NS is locality ground-truth preservation."
        ),
    )
    failures = [
        {
            "method": row["method"],
            "case_id": index,
            "subject": record.get("subject", ""),
            "prompt": record.get("prompt", ""),
            "target_new": record.get("target_new", ""),
            "direct_answer": record.get("direct_answer", ""),
            "rephrase_answer": record.get("rephrase_answer", ""),
            "locality_answer": record.get("locality_answer", ""),
            "failed_metrics": failed_metric_names(
                record,
                {
                    "ES": "direct_contains_target_new",
                    "PS": "rephrase_contains_target_new",
                    "NS": "locality_contains_ground_truth",
                },
            ),
        }
        for index, record in enumerate(records, start=1)
        if not (
            record.get("direct_contains_target_new")
            and record.get("rephrase_contains_target_new")
            and record.get("locality_contains_ground_truth")
        )
    ]
    return row, failures


def evaluate_rome(path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    records = load_json(path)
    if not isinstance(records, list):
        raise ValueError(f"ROME file must contain a list: {path}")
    completed = [record for record in records if "error" not in record]
    total = len(completed)
    row = metric_row(
        method="ROME",
        source_file=path,
        edited_records=total,
        evaluated_records=total,
        es_count=count_true(completed, "efficacy_success"),
        es_total=total,
        ps_count=count_true(completed, "generalization_success"),
        ps_total=total,
        ns_count=count_true(completed, "locality_success"),
        ns_total=total,
        edit_time_seconds=round(
            sum(float(record.get("edit_time_seconds", 0.0)) for record in completed), 4
        ),
        max_cuda_memory_mb=max(
            [float(record.get("max_cuda_memory_mb", 0.0)) for record in completed]
            or [0.0]
        ),
        notes="Each fact was edited independently, with original weights restored.",
    )
    failures = [
        {
            "method": row["method"],
            "case_id": record.get("case_id"),
            "subject": record.get("subject", ""),
            "prompt": record.get("prompt", ""),
            "target_new": record.get("target_new", ""),
            "direct_answer": record.get("post_direct_answer", ""),
            "rephrase_answer": record.get("post_rephrase_answer", ""),
            "locality_answer": record.get("post_locality_answer", ""),
            "failed_metrics": failed_metric_names(
                record,
                {
                    "ES": "efficacy_success",
                    "PS": "generalization_success",
                    "NS": "locality_success",
                },
            ),
        }
        for record in completed
        if not (
            record.get("efficacy_success")
            and record.get("generalization_success")
            and record.get("locality_success")
        )
    ]
    return row, failures


def evaluate_memit(path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    payload = load_json(path)
    if not isinstance(payload, dict):
        raise ValueError(f"MEMIT file must contain an object: {path}")
    summary = payload.get("summary", {})
    records = payload.get("eval_results", [])
    if not isinstance(records, list):
        raise ValueError(f"MEMIT eval_results must be a list: {path}")
    total = len(records)
    row = metric_row(
        method="MEMIT",
        source_file=path,
        edited_records=int(summary.get("edited_requests", total) or 0),
        evaluated_records=total,
        es_count=count_true(records, "efficacy_success"),
        es_total=total,
        ps_count=count_true(records, "generalization_success"),
        ps_total=total,
        ns_count=count_true(records, "locality_no_target_new"),
        ns_total=total,
        edit_time_seconds=summary.get("edit_time_seconds"),
        max_cuda_memory_mb=summary.get("max_cuda_memory_mb"),
        notes=(
            "Batch edit over CounterFact. NS is measured as locality prompt not "
            "leaking the edited target_new, because CounterFact neighborhood "
            "prompts do not include explicit locality ground-truth answers here."
        ),
    )
    failures = [
        {
            "method": row["method"],
            "case_id": record.get("case_id"),
            "subject": record.get("subject", ""),
            "prompt": record.get("prompt", ""),
            "target_new": record.get("target_new", ""),
            "direct_answer": record.get("direct_answer", ""),
            "rephrase_answer": record.get("rephrase_answer", ""),
            "locality_answer": record.get("locality_answer", ""),
            "failed_metrics": failed_metric_names(
                record,
                {
                    "ES": "efficacy_success",
                    "PS": "generalization_success",
                    "NS": "locality_no_target_new",
                },
            ),
        }
        for record in records
        if not (
            record.get("efficacy_success")
            and record.get("generalization_success")
            and record.get("locality_no_target_new")
        )
    ]
    return row, failures


def failed_metric_names(record: dict[str, Any], mapping: dict[str, str]) -> str:
    failed = [name for name, key in mapping.items() if record.get(key) is not True]
    return ",".join(failed)


def write_csv(rows: list[dict[str, Any]], path: Path) -> None:
    fieldnames = [
        "method",
        "source_file",
        "edited_records",
        "evaluated_records",
        "ES_count",
        "ES_total",
        "ES_percent",
        "PS_count",
        "PS_total",
        "PS_percent",
        "NS_count",
        "NS_total",
        "NS_percent",
        "edit_time_seconds",
        "max_cuda_memory_mb",
        "notes",
    ]
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def short_text(text: Any, limit: int = 100) -> str:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    return text if len(text) <= limit else text[: limit - 3] + "..."


def markdown_table(rows: list[dict[str, Any]]) -> str:
    lines = [
        "| Method | Edited | Evaluated | ES | PS | NS | Time(s) | Peak MB |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in rows:
        lines.append(
            "| {method} | {edited_records} | {evaluated_records} | "
            "{ES_count}/{ES_total} ({ES_percent:.2f}%) | "
            "{PS_count}/{PS_total} ({PS_percent:.2f}%) | "
            "{NS_count}/{NS_total} ({NS_percent:.2f}%) | "
            "{time_value} | {memory_value} |".format(
                **row,
                time_value=(
                    "" if row["edit_time_seconds"] is None else row["edit_time_seconds"]
                ),
                memory_value=(
                    "" if row["max_cuda_memory_mb"] is None else row["max_cuda_memory_mb"]
                ),
            )
        )
    return "\n".join(lines)


def write_markdown(
    rows: list[dict[str, Any]],
    failures_by_method: dict[str, list[dict[str, Any]]],
    path: Path,
    failure_limit: int,
) -> None:
    lines = [
        "# Task 4 Evaluation Summary",
        "",
        markdown_table(rows),
        "",
        "## Notes",
        "",
    ]
    for row in rows:
        lines.append(f"- {row['method']}: {row['notes']}")

    lines.extend(["", "## Failure Examples", ""])
    for method, failures in failures_by_method.items():
        lines.append(f"### {method}")
        if not failures:
            lines.append("")
            lines.append("No failed examples in the evaluated set.")
            lines.append("")
            continue
        for item in failures[:failure_limit]:
            lines.append(
                "- case={case_id}, failed={failed}, subject={subject}, "
                "target={target}, answer={answer}".format(
                    case_id=item.get("case_id"),
                    failed=item.get("failed_metrics", ""),
                    subject=short_text(item.get("subject")),
                    target=short_text(item.get("target_new"), 60),
                    answer=short_text(item.get("direct_answer")),
                )
            )
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")


def method_label(method: str) -> str:
    labels = {
        "Baseline (pre-edit)": "Baseline",
        "ROME": "ROME",
        "MEMIT": "MEMIT",
    }
    return labels.get(method, method)


def metric_cell(row: dict[str, Any], prefix: str) -> str:
    return (
        f"{row[f'{prefix}_count']}/{row[f'{prefix}_total']} "
        f"({row[f'{prefix}_percent']:.2f}%)"
    )


def optional_number(value: Any, suffix: str = "") -> str:
    return "-" if value is None else f"{value}{suffix}"


def failure_type_table(failures: list[dict[str, Any]]) -> list[str]:
    counts = Counter(item.get("failed_metrics", "") for item in failures)
    lines = [
        "| 失败类型 | 数量 | 说明 |",
        "| --- | ---: | --- |",
    ]
    descriptions = {
        "PS": "直接 prompt 成功，但改写 prompt 未输出目标答案，是主要失败来源。",
        "ES,PS": "直接 prompt 和改写 prompt 都失败，说明该事实编辑不充分。",
        "NS": "locality prompt 中泄露了目标新答案或局部性未保持。",
        "PS,NS": "改写泛化失败，同时 locality 也受到影响。",
        "ES": "直接 prompt 未命中。",
        "ES,NS": "直接 prompt 未命中，同时 locality 也受到影响。",
        "ES,PS,NS": "三项指标均失败。",
    }
    for failure_type, count in counts.most_common():
        lines.append(
            f"| {failure_type or 'Unknown'} | {count} | "
            f"{descriptions.get(failure_type, '该组合指标未全部通过。')} |"
        )
    return lines


def write_chinese_report(
    rows: list[dict[str, Any]],
    failures_by_method: dict[str, list[dict[str, Any]]],
    path: Path,
    failure_limit: int,
) -> None:
    by_method = {row["method"]: row for row in rows}
    memit_failures = failures_by_method.get("MEMIT", [])
    memit_row = by_method.get("MEMIT", {})

    lines = [
        "# Task 4 综合评估报告",
        "",
        "## 评估设置",
        "",
    ]
    for row in rows:
        lines.append(f"- {method_label(row['method'])} 数据：`{row['source_file']}`")

    lines.extend(
        [
            "",
            "## 指标定义",
            "",
            "- ES：Efficacy，直接编辑 prompt 是否输出目标新答案。",
            "- PS：Generalization / Paraphrase，改写 prompt 是否仍能输出目标新答案。",
            "- NS：Locality，局部性是否保持。Baseline 和 ROME 使用 locality ground truth 判断；MEMIT 的 CounterFact neighborhood prompt 没有显式 ground truth，因此使用 locality prompt 不泄露 `target_new` 作为局部性近似指标。",
            "",
            "## 综合结果",
            "",
            "| 方法 | 编辑条数 | 评估条数 | ES | PS | NS | 耗时 | 峰值显存 |",
            "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for row in rows:
        lines.append(
            f"| {method_label(row['method'])} | {row['edited_records']} | "
            f"{row['evaluated_records']} | {metric_cell(row, 'ES')} | "
            f"{metric_cell(row, 'PS')} | {metric_cell(row, 'NS')} | "
            f"{optional_number(row['edit_time_seconds'], 's')} | "
            f"{optional_number(row['max_cuda_memory_mb'], ' MB')} |"
        )

    baseline = by_method.get("Baseline (pre-edit)", {})
    rome = by_method.get("ROME", {})
    lines.extend(
        [
            "",
            "## 结果分析",
            "",
            (
                "Baseline 结果显示，未编辑模型对自定义事实的直接命中率为 "
                f"{baseline.get('ES_percent', 0):.2f}%，改写 prompt 命中率为 "
                f"{baseline.get('PS_percent', 0):.2f}%，说明 Task 1 数据能够体现模型存在旧知识或知识缺失问题。"
            ),
            "",
            (
                "ROME 对 10 条自定义事实逐条编辑后，直接编辑成功率为 "
                f"{rome.get('ES_percent', 0):.2f}%，PS 为 {rome.get('PS_percent', 0):.2f}%，"
                f"NS 为 {rome.get('NS_percent', 0):.2f}%。这说明单条事实注入有效，但改写泛化和无关事实保持仍有波动。"
            ),
            "",
            (
                "MEMIT 一次性批量编辑 "
                f"{memit_row.get('edited_records', 0)} 条 CounterFact 数据后，ES 为 "
                f"{memit_row.get('ES_percent', 0):.2f}%，NS 为 {memit_row.get('NS_percent', 0):.2f}%，"
                f"说明批量知识注入整体有效且局部性保持较好。PS 为 {memit_row.get('PS_percent', 0):.2f}%，"
                "低于 ES，表明同义改写 prompt 下的稳定泛化是主要瓶颈。"
            ),
            "",
            "## MEMIT 失败案例总结",
            "",
            (
                f"MEMIT 共 {len(memit_failures)} 条样本未能同时满足 ES、PS、NS 三项指标。"
                "失败类型分布如下："
            ),
            "",
        ]
    )
    lines.extend(failure_type_table(memit_failures))
    lines.extend(
        [
            "",
            "典型失败样例：",
            "",
            "| case_id | 失败类型 | subject | target_new |",
            "| ---: | --- | --- | --- |",
        ]
    )
    for item in memit_failures[:failure_limit]:
        lines.append(
            f"| {item.get('case_id')} | {item.get('failed_metrics', '')} | "
            f"{short_text(item.get('subject'), 40)} | "
            f"{short_text(item.get('target_new'), 40)} |"
        )

    lines.extend(
        [
            "",
            "整体来看，MEMIT 在本实验中比 ROME 更适合大规模知识注入。主要不足是 paraphrase prompt 下的泛化能力不足，后续可以通过调整 MEMIT 层范围、增加 covariance 样本量、优化 prompt 模板或使用更强基础模型进行改进。",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def write_outputs(
    rows: list[dict[str, Any]],
    failures_by_method: dict[str, list[dict[str, Any]]],
    output_dir: Path,
    failure_limit: int,
    write_report: bool,
) -> tuple[Path, Path, Path, Path | None]:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    json_path = output_dir / f"evaluation_summary_{timestamp}.json"
    csv_path = output_dir / f"evaluation_summary_{timestamp}.csv"
    md_path = output_dir / f"evaluation_summary_{timestamp}.md"
    report_path = output_dir / f"task4_report_{timestamp}.md" if write_report else None

    payload = {
        "created_at": timestamp,
        "metrics": rows,
        "failures": failures_by_method,
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(rows, csv_path)
    write_markdown(rows, failures_by_method, md_path, failure_limit)
    if report_path is not None:
        write_chinese_report(rows, failures_by_method, report_path, failure_limit)
        write_chinese_report(rows, failures_by_method, output_dir / "task4_report.md", failure_limit)
    return json_path, csv_path, md_path, report_path


def print_summary(
    rows: list[dict[str, Any]],
    paths: tuple[Path, Path, Path, Path | None],
) -> None:
    print("\nTask 4 evaluation summary")
    print(markdown_table(rows))
    print("\nOutputs")
    print(f"- JSON: {paths[0]}")
    print(f"- CSV: {paths[1]}")
    print(f"- Markdown: {paths[2]}")
    if paths[3] is not None:
        print(f"- Chinese report: {paths[3]}")
        print(f"- Latest Chinese report: {paths[3].parent / 'task4_report.md'}")


def main() -> None:
    configure_stdio()
    args = parse_args()
    baseline_path, rome_path, memit_path = resolve_paths(args)

    baseline_row, baseline_failures = evaluate_baseline(baseline_path)
    rome_row, rome_failures = evaluate_rome(rome_path)
    memit_row, memit_failures = evaluate_memit(memit_path)

    rows = [baseline_row, rome_row, memit_row]
    failures_by_method = {
        baseline_row["method"]: baseline_failures,
        rome_row["method"]: rome_failures,
        memit_row["method"]: memit_failures,
    }
    output_paths = write_outputs(
        rows,
        failures_by_method,
        args.output_dir,
        args.failure_limit,
        write_report=not args.skip_report,
    )
    print_summary(rows, output_paths)


if __name__ == "__main__":
    main()
