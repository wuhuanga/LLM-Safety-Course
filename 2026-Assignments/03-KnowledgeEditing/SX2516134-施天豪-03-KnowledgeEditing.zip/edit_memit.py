"""Batch MEMIT editing script for Task 3.

The script can prepare a 500-item CounterFact subset and then apply EasyEdit's
MEMIT implementation once to the full batch. It records wall-clock time, peak
CUDA memory, and optional post-edit generations for a small evaluation sample.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import importlib.util
import json
import re
import sys
import time
import unicodedata
import urllib.request
import warnings
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=FutureWarning, module="transformers")
warnings.filterwarnings("ignore", category=FutureWarning, module="huggingface_hub")


DEFAULT_MODEL = "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_DATA_PATH = Path("data/counterfact_500.json")
DEFAULT_RAW_COUNTERFACT_PATH = Path("data/raw/counterfact.json")
DEFAULT_COV_TEXT_PATH = Path("data/memit_cov_texts.jsonl")
DEFAULT_COUNTERFACT_URL = "https://rome.baulab.info/data/dsets/counterfact.json"
DEFAULT_HPARAMS_PATH = Path("hparams/MEMIT/qwen2.5-0.5b.yaml")
DEFAULT_OUTPUT_DIR = Path("outputs")
DEFAULT_CACHE_TEMPLATE = "data/cache/memit_z/layer{}_clamp{}_case{}.npz"
PROJECT_ROOT = Path(__file__).resolve().parent
LOCAL_EASYEDIT_PATH = PROJECT_ROOT / "external" / "EasyEdit"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run one-shot MEMIT batch editing with EasyEdit for Task 3."
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Hugging Face model id or local path. Default: {DEFAULT_MODEL}",
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=DEFAULT_DATA_PATH,
        help=f"Prepared CounterFact subset path. Default: {DEFAULT_DATA_PATH}",
    )
    parser.add_argument(
        "--raw-counterfact",
        type=Path,
        default=DEFAULT_RAW_COUNTERFACT_PATH,
        help=f"Raw CounterFact cache path. Default: {DEFAULT_RAW_COUNTERFACT_PATH}",
    )
    parser.add_argument(
        "--cov-texts",
        type=Path,
        default=DEFAULT_COV_TEXT_PATH,
        help=f"Local JSONL text file for covariance stats. Default: {DEFAULT_COV_TEXT_PATH}",
    )
    parser.add_argument(
        "--counterfact-url",
        default=DEFAULT_COUNTERFACT_URL,
        help=f"CounterFact JSON URL. Default: {DEFAULT_COUNTERFACT_URL}",
    )
    parser.add_argument(
        "--hparams",
        type=Path,
        default=DEFAULT_HPARAMS_PATH,
        help=f"EasyEdit MEMIT hparams YAML. Default: {DEFAULT_HPARAMS_PATH}",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Directory for MEMIT outputs. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--device",
        default="0",
        help="CUDA device index, for example 0 or cuda:0. Default: 0",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional limit for editing fewer than 500 records.",
    )
    parser.add_argument(
        "--offset",
        type=int,
        default=0,
        help="Offset used when preparing a CounterFact subset. Default: 0",
    )
    parser.add_argument(
        "--prepare-size",
        type=int,
        default=500,
        help="Number of CounterFact records to write during --prepare-data. Default: 500",
    )
    parser.add_argument(
        "--prepare-data",
        action="store_true",
        help="Download/convert CounterFact and exit without running MEMIT.",
    )
    parser.add_argument(
        "--force-download",
        action="store_true",
        help="Download raw CounterFact even if the cache file already exists.",
    )
    parser.add_argument(
        "--eval-limit",
        type=int,
        default=500,
        help="Number of edited records to evaluate with generation. Use 0 to skip. Default: 500",
    )
    parser.add_argument(
        "--eval-progress-interval",
        type=int,
        default=10,
        help="Print post-edit generation progress every N evaluated records. Default: 10",
    )
    parser.add_argument(
        "--max-new-tokens",
        type=int,
        default=24,
        help="Maximum generated tokens for optional verification. Default: 24",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
        help="Sampling temperature. 0 uses greedy decoding. Default: 0",
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=0.9,
        help="Top-p value used only when temperature > 0. Default: 0.9",
    )
    parser.add_argument(
        "--fp16",
        action="store_true",
        help="Load the model in float16 through EasyEdit hparams.",
    )
    parser.add_argument(
        "--layers",
        default=None,
        help="Override MEMIT layers, e.g. 4,5,6,7,8.",
    )
    parser.add_argument(
        "--v-num-grad-steps",
        type=int,
        default=None,
        help="Override MEMIT v_num_grad_steps for faster smoke tests.",
    )
    parser.add_argument(
        "--mom2-n-samples",
        type=int,
        default=None,
        help="Override covariance sample count. Useful for smoke tests.",
    )
    parser.add_argument(
        "--mom2-dataset",
        default=None,
        help="Override covariance text dataset. Can be wikitext, wikipedia, or a local text/JSONL file.",
    )
    parser.add_argument(
        "--mom2-update-weight",
        type=float,
        default=None,
        help="Override MEMIT covariance update weight.",
    )
    parser.add_argument(
        "--cache-template",
        default=DEFAULT_CACHE_TEMPLATE,
        help="NPZ cache template for MEMIT z vectors. Use --disable-cache to turn off.",
    )
    parser.add_argument(
        "--disable-cache",
        action="store_true",
        help="Disable MEMIT z-vector cache.",
    )
    parser.add_argument(
        "--keep-edited-weights",
        action="store_true",
        help="Do not restore original weights before exit.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate files and dataset fields without importing EasyEdit or torch.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show Transformers/EasyEdit logs and warnings.",
    )
    return parser.parse_args()


def configure_stdio() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def aliases_for(record: dict[str, Any], field: str) -> list[str]:
    values = []
    value = record.get(field)
    aliases = record.get(f"aliases_{field}", [])
    if isinstance(value, str):
        values.append(value)
    if isinstance(aliases, list):
        values.extend(str(alias) for alias in aliases)
    return values


def contains_any(answer: str, candidates: list[str]) -> bool:
    normalized_answer = normalize_text(answer)
    return any(normalize_text(candidate) in normalized_answer for candidate in candidates)


def prompt_text(record: dict[str, Any], key: str = "prompt") -> str:
    prompt = record[key]
    return prompt.format(record["subject"]) if "{}" in prompt else prompt


def download_counterfact(url: str, raw_path: Path, force: bool = False) -> None:
    if raw_path.exists() and not force:
        print(f"Raw CounterFact cache exists: {raw_path}")
        return
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading CounterFact from {url}")
    print(f"Saving to {raw_path}")
    urllib.request.urlretrieve(url, raw_path)


def first_text(values: Any, fallback: str) -> str:
    if isinstance(values, list):
        for value in values:
            if isinstance(value, str) and value.strip():
                return value
    return fallback


def target_str(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("str", "")).strip()
    return str(value).strip()


def convert_counterfact_record(
    raw: dict[str, Any],
    source_url: str = DEFAULT_COUNTERFACT_URL,
) -> dict[str, Any] | None:
    rewrite = raw.get("requested_rewrite")
    if not isinstance(rewrite, dict):
        return None

    subject = str(rewrite.get("subject", "")).strip()
    prompt = str(rewrite.get("prompt", "")).strip()
    target_new = target_str(rewrite.get("target_new"))
    ground_truth = target_str(rewrite.get("target_true"))
    if not subject or not prompt or not target_new or not ground_truth:
        return None
    if "{}" not in prompt and subject not in prompt:
        return None

    direct_prompt = prompt.format(subject) if "{}" in prompt else prompt
    rephrase_prompt = first_text(raw.get("paraphrase_prompts"), direct_prompt)
    locality_prompt = first_text(raw.get("neighborhood_prompts"), direct_prompt)

    return {
        "case_id": int(raw.get("case_id", 0)),
        "prompt": prompt,
        "subject": subject,
        "target_new": target_new,
        "ground_truth": ground_truth,
        "rephrase_prompt": rephrase_prompt,
        "locality_prompt": locality_prompt,
        "locality_target_not_expected": target_new,
        "source_dataset": "CounterFact",
        "source_url": source_url,
    }


def prepare_counterfact_subset(args: argparse.Namespace) -> None:
    download_counterfact(args.counterfact_url, args.raw_counterfact, args.force_download)
    with args.raw_counterfact.open("r", encoding="utf-8") as f:
        raw_data = json.load(f)
    if not isinstance(raw_data, list):
        raise ValueError("Raw CounterFact file must contain a JSON list.")

    converted = []
    for raw in raw_data[args.offset :]:
        record = convert_counterfact_record(raw, args.counterfact_url)
        if record is None:
            continue
        converted.append(record)
        if len(converted) >= args.prepare_size:
            break

    if len(converted) < args.prepare_size:
        raise ValueError(
            f"Only prepared {len(converted)} records, expected {args.prepare_size}."
        )

    args.data.parent.mkdir(parents=True, exist_ok=True)
    with args.data.open("w", encoding="utf-8") as f:
        json.dump(converted, f, ensure_ascii=False, indent=2)

    args.cov_texts.parent.mkdir(parents=True, exist_ok=True)
    with args.cov_texts.open("w", encoding="utf-8") as f:
        for record in converted:
            texts = [
                prompt_text(record),
                record["rephrase_prompt"],
                record["locality_prompt"],
            ]
            for text in texts:
                f.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")

    print("Prepared CounterFact subset")
    print(f"- Raw records: {len(raw_data)}")
    print(f"- Written records: {len(converted)}")
    print(f"- Output: {args.data}")
    print(f"- Covariance texts: {args.cov_texts}")


def load_dataset(path: Path, limit: int | None) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset file not found: {path}. Prepare it with:\n"
            f"  python edit_memit.py --prepare-data"
        )
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("Dataset must be a JSON list.")

    required = {
        "case_id",
        "prompt",
        "subject",
        "target_new",
        "ground_truth",
        "rephrase_prompt",
        "locality_prompt",
    }
    for index, record in enumerate(data, start=1):
        missing = required - set(record)
        if missing:
            raise ValueError(f"Record {index} is missing fields: {sorted(missing)}")
        if "{}" not in record["prompt"] and record["subject"] not in record["prompt"]:
            raise ValueError(
                f"Record {index} prompt must contain '{{}}' or the subject for MEMIT."
            )

    return data[:limit] if limit else data


def parse_cuda_index(device_arg: str) -> int:
    cleaned = device_arg.lower().replace("cuda:", "").strip()
    if not cleaned.isdigit():
        raise ValueError("--device must be a CUDA index like 0 or cuda:0")
    return int(cleaned)


def parse_layers(value: str | None) -> list[int] | None:
    if value is None:
        return None
    layers = [item.strip() for item in value.split(",") if item.strip()]
    if not layers:
        raise ValueError("--layers must contain at least one integer.")
    return [int(layer) for layer in layers]


def add_local_easyedit_to_path() -> None:
    if importlib.util.find_spec("easyeditor") is not None:
        return
    if (LOCAL_EASYEDIT_PATH / "easyeditor").exists():
        sys.path.insert(0, str(LOCAL_EASYEDIT_PATH))


def ensure_easyedit_available() -> None:
    add_local_easyedit_to_path()
    if importlib.util.find_spec("easyeditor") is None:
        raise ModuleNotFoundError(
            "EasyEdit is not importable. Keep the cloned EasyEdit source at "
            "external/EasyEdit or add it to PYTHONPATH, then install the "
            "dependencies from requirements.txt."
        )


def import_easyedit() -> tuple[Any, Any]:
    add_local_easyedit_to_path()
    try:
        easyeditor = importlib.import_module("easyeditor")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "EasyEdit is not importable. Keep the cloned EasyEdit source at "
            "external/EasyEdit or add it to PYTHONPATH, then install the "
            "dependencies from requirements.txt."
        ) from exc

    try:
        return easyeditor.MEMITHyperParams, easyeditor.BaseEditor
    except AttributeError as exc:
        raise RuntimeError(
            "The installed easyeditor package does not expose MEMITHyperParams "
            "and BaseEditor. Please install/update zjunlp/EasyEdit."
        ) from exc


def configure_hparams(
    hparams_cls: Any,
    args: argparse.Namespace,
    device_index: int,
) -> Any:
    if not args.hparams.exists():
        raise FileNotFoundError(f"MEMIT hparams file not found: {args.hparams}")

    hparams = hparams_cls.from_hparams(str(args.hparams))
    hparams.model_name = args.model
    hparams.device = device_index
    hparams.fp16 = args.fp16
    hparams.model_parallel = False

    layers = parse_layers(args.layers)
    if layers is not None:
        hparams.layers = layers
    if args.v_num_grad_steps is not None:
        hparams.v_num_grad_steps = args.v_num_grad_steps
    if args.mom2_n_samples is not None:
        hparams.mom2_n_samples = args.mom2_n_samples
    if args.mom2_dataset is not None:
        hparams.mom2_dataset = args.mom2_dataset
    if args.mom2_update_weight is not None:
        hparams.mom2_update_weight = args.mom2_update_weight
    return hparams


def ensure_cuda(torch: Any, device_index: int) -> None:
    if not torch.cuda.is_available():
        raise RuntimeError(
            "EasyEdit's MEMIT implementation expects CUDA. "
            "Use the `easyedit` environment with CUDA PyTorch."
        )
    if device_index >= torch.cuda.device_count():
        raise RuntimeError(
            f"CUDA device {device_index} is not available. "
            f"Visible device count: {torch.cuda.device_count()}"
        )


def build_easyedit_request(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "case_id": int(record["case_id"]),
        "prompt": record["prompt"],
        "subject": record["subject"],
        "target_new": record["target_new"],
        "ground_truth": record["ground_truth"],
        "rephrase_prompt": record["rephrase_prompt"],
        "locality": {},
        "portability": {},
    }


def generation_kwargs(
    tokenizer: Any,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "max_new_tokens": max_new_tokens,
        "pad_token_id": tokenizer.pad_token_id or tokenizer.eos_token_id,
        "eos_token_id": tokenizer.eos_token_id,
    }
    if temperature > 0:
        kwargs.update({"do_sample": True, "temperature": temperature, "top_p": top_p})
    else:
        kwargs.update(
            {"do_sample": False, "temperature": None, "top_p": None, "top_k": None}
        )
    return kwargs


def generate_answer(
    torch: Any,
    model: Any,
    tokenizer: Any,
    prompt: str,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
) -> str:
    device = next(model.parameters()).device
    encoded = tokenizer(prompt, return_tensors="pt").to(device)
    with torch.inference_mode():
        output_ids = model.generate(
            **encoded,
            **generation_kwargs(tokenizer, max_new_tokens, temperature, top_p),
        )
    new_tokens = output_ids[0, encoded["input_ids"].shape[-1] :]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def restore_original_weights(torch: Any, model: Any, weights_copy: dict[str, Any]) -> None:
    if not weights_copy:
        return
    named_parameters = dict(model.named_parameters())
    with torch.no_grad():
        for name, original_value in weights_copy.items():
            if name not in named_parameters:
                raise KeyError(f"Edited parameter not found during restore: {name}")
            parameter = named_parameters[name]
            parameter[...] = original_value.to(device=parameter.device, dtype=parameter.dtype)


def evaluate_records(
    args: argparse.Namespace,
    torch: Any,
    model: Any,
    tokenizer: Any,
    records: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if args.eval_limit <= 0:
        return []

    eval_records = records[: args.eval_limit]
    total = len(eval_records)
    print(f"Evaluating {total} edited records with generation...", flush=True)
    results = []
    for index, record in enumerate(eval_records, start=1):
        target_aliases = aliases_for(record, "target_new")
        direct_answer = generate_answer(
            torch,
            model,
            tokenizer,
            prompt_text(record),
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        rephrase_answer = generate_answer(
            torch,
            model,
            tokenizer,
            record["rephrase_prompt"],
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        locality_answer = generate_answer(
            torch,
            model,
            tokenizer,
            record["locality_prompt"],
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        results.append(
            {
                "eval_id": index,
                "case_id": record["case_id"],
                "subject": record["subject"],
                "prompt": prompt_text(record),
                "target_new": record["target_new"],
                "ground_truth": record["ground_truth"],
                "direct_answer": direct_answer,
                "rephrase_prompt": record["rephrase_prompt"],
                "rephrase_answer": rephrase_answer,
                "locality_prompt": record["locality_prompt"],
                "locality_answer": locality_answer,
                "efficacy_success": contains_any(direct_answer, target_aliases),
                "generalization_success": contains_any(rephrase_answer, target_aliases),
                "locality_no_target_new": not contains_any(
                    locality_answer, target_aliases
                ),
            }
        )
        if (
            args.eval_progress_interval > 0
            and (index == 1 or index % args.eval_progress_interval == 0 or index == total)
        ):
            print(f"Evaluation progress: {index}/{total}", flush=True)
    return results


def jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if hasattr(value, "detach"):
        value = value.detach().cpu()
    if hasattr(value, "tolist"):
        return value.tolist()
    if hasattr(value, "item"):
        return value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def write_outputs(
    output_dir: Path,
    model_name: str,
    summary: dict[str, Any],
    eval_results: list[dict[str, Any]],
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_model = re.sub(r"[^A-Za-z0-9_.-]+", "_", model_name).strip("_")
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    json_path = output_dir / f"memit_{safe_model}_{timestamp}.json"
    csv_path = output_dir / f"memit_{safe_model}_{timestamp}.csv"

    payload = {
        "summary": summary,
        "eval_results": eval_results,
    }
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(jsonable(payload), f, ensure_ascii=False, indent=2)

    fieldnames = [
        "eval_id",
        "case_id",
        "subject",
        "prompt",
        "target_new",
        "ground_truth",
        "direct_answer",
        "efficacy_success",
        "rephrase_prompt",
        "rephrase_answer",
        "generalization_success",
        "locality_prompt",
        "locality_answer",
        "locality_no_target_new",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(eval_results)

    return json_path, csv_path


def count_true(results: list[dict[str, Any]], key: str) -> int:
    return sum(1 for result in results if result.get(key) is True)


def print_summary(
    summary: dict[str, Any],
    eval_results: list[dict[str, Any]],
    json_path: Path,
    csv_path: Path,
) -> None:
    print("\nMEMIT summary")
    print(f"- Edited requests: {summary['edited_requests']}")
    print(f"- MEMIT edit time: {summary['edit_time_seconds']} seconds")
    print(f"- Peak CUDA memory: {summary['max_cuda_memory_mb']} MB")
    print(f"- Layers: {summary['layers']}")
    print(f"- mom2_n_samples: {summary['mom2_n_samples']}")
    print(f"- mom2_dataset: {summary['mom2_dataset']}")
    if eval_results:
        total = len(eval_results)
        print(f"- Evaluated records: {total}")
        print(f"- Efficacy success: {count_true(eval_results, 'efficacy_success')}/{total}")
        print(
            "- Generalization success: "
            f"{count_true(eval_results, 'generalization_success')}/{total}"
        )
        print(
            "- Locality no-target-new: "
            f"{count_true(eval_results, 'locality_no_target_new')}/{total}"
        )
    else:
        print("- Evaluated records: 0")
    print(f"- JSON output: {json_path}")
    print(f"- CSV output: {csv_path}")


def dry_run(args: argparse.Namespace) -> None:
    data = load_dataset(args.data, args.limit)
    if not args.hparams.exists():
        raise FileNotFoundError(f"MEMIT hparams file not found: {args.hparams}")
    device_index = parse_cuda_index(args.device)
    layers = parse_layers(args.layers)
    print("Dry run OK")
    print(f"- Dataset: {args.data} ({len(data)} records selected)")
    print(f"- Hparams: {args.hparams}")
    print(f"- Model: {args.model}")
    print(f"- CUDA device index: {device_index}")
    print(f"- Layers override: {layers if layers is not None else 'from hparams'}")
    print("- EasyEdit and torch were not imported in dry-run mode.")


def run_memit(args: argparse.Namespace) -> None:
    data = load_dataset(args.data, args.limit)
    device_index = parse_cuda_index(args.device)

    ensure_easyedit_available()
    torch = importlib.import_module("torch")
    ensure_cuda(torch, device_index)
    torch.cuda.set_device(device_index)

    hparams_cls, base_editor_cls = import_easyedit()
    hparams = configure_hparams(hparams_cls, args, device_index)
    if hparams.mom2_dataset not in {"wikitext", "wikipedia"}:
        cov_path = Path(hparams.mom2_dataset)
        if not cov_path.exists():
            raise FileNotFoundError(
                f"Local covariance text dataset not found: {cov_path}. "
                "Prepare it with: python edit_memit.py --prepare-data"
            )
    requests = [build_easyedit_request(record) for record in data]

    print(f"Loading editor with model: {hparams.model_name}")
    print(f"MEMIT hparams: {args.hparams}")
    print(f"CUDA device: cuda:{device_index}")
    print(f"Dataset: {args.data} ({len(data)} records)")
    print(f"Layers: {hparams.layers}")
    print(f"mom2_n_samples: {hparams.mom2_n_samples}")
    editor = base_editor_cls.from_hparams(hparams)

    cuda_device = torch.device(f"cuda:{device_index}")
    torch.cuda.reset_peak_memory_stats(cuda_device)
    start = time.perf_counter()
    edited_model, weights_copy = editor.apply_algo(
        editor.model,
        editor.tok,
        requests,
        editor.hparams,
        copy=False,
        return_orig_weights=True,
        keep_original_weight=False,
        cache_template=None if args.disable_cache else args.cache_template,
    )
    edit_time = time.perf_counter() - start
    peak_memory_mb = torch.cuda.max_memory_allocated(cuda_device) / (1024**2)

    eval_results = evaluate_records(args, torch, edited_model, editor.tok, data)

    if not args.keep_edited_weights:
        restore_original_weights(torch, editor.model, weights_copy)
        torch.cuda.empty_cache()

    summary = {
        "model": hparams.model_name,
        "data_path": str(args.data),
        "edited_requests": len(data),
        "eval_limit": args.eval_limit,
        "edit_time_seconds": round(edit_time, 4),
        "max_cuda_memory_mb": round(peak_memory_mb, 2),
        "layers": list(hparams.layers),
        "v_num_grad_steps": hparams.v_num_grad_steps,
        "mom2_n_samples": hparams.mom2_n_samples,
        "mom2_dataset": hparams.mom2_dataset,
        "mom2_update_weight": hparams.mom2_update_weight,
        "fp16": bool(args.fp16),
        "z_cache_enabled": not args.disable_cache,
    }
    json_path, csv_path = write_outputs(
        args.output_dir, hparams.model_name, summary, eval_results
    )
    print_summary(summary, eval_results, json_path, csv_path)


def main() -> None:
    configure_stdio()
    args = parse_args()

    if args.prepare_data:
        prepare_counterfact_subset(args)
        return

    if args.dry_run:
        dry_run(args)
        return

    if not args.verbose:
        try:
            from transformers.utils import logging as transformers_logging

            transformers_logging.set_verbosity_error()
        except Exception:
            pass

    run_memit(args)


if __name__ == "__main__":
    main()
