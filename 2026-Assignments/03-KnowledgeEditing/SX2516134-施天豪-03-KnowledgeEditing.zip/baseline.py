"""Baseline evaluation script for Task 1.

This script loads a 10-item factual-update dataset, queries the original model
without applying any knowledge editing, and records direct/rephrased/locality
answers for later comparison with ROME/MEMIT results.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
import unicodedata
import warnings
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=FutureWarning, module="transformers")
warnings.filterwarnings("ignore", category=FutureWarning, module="huggingface_hub")

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.utils import logging as transformers_logging


DEFAULT_MODEL = "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_DATA_PATH = Path("data/baseline_facts.json")
DEFAULT_OUTPUT_DIR = Path("outputs")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run baseline inference before knowledge editing."
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Hugging Face model id or local path. Default: {DEFAULT_MODEL}",
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=DEFAULT_DATA_PATH,
        help=f"JSON dataset path. Default: {DEFAULT_DATA_PATH}",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Directory for baseline outputs. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--device",
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Inference device. Default: auto",
    )
    parser.add_argument(
        "--max-new-tokens",
        type=int,
        default=32,
        help="Maximum tokens generated for each prompt. Default: 32",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
        help="Sampling temperature. 0 uses greedy decoding. Default: 0",
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=0.9,
        help="Top-p value used only when temperature > 0. Default: 0.9",
    )
    parser.add_argument(
        "--chat",
        action="store_true",
        help="Use the tokenizer chat template instead of raw completion prompts.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional limit for quick smoke tests.",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Pass trust_remote_code=True to Transformers loaders.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show Transformers and Hugging Face Hub warnings.",
    )
    return parser.parse_args()


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def aliases_for(record: dict[str, Any], field: str) -> list[str]:
    value = record.get(field)
    aliases = record.get(f"aliases_{field}", [])
    values = []
    if isinstance(value, str):
        values.append(value)
    if isinstance(aliases, list):
        values.extend(str(alias) for alias in aliases)
    return values


def contains_any(answer: str, candidates: list[str]) -> bool:
    normalized_answer = normalize_text(answer)
    return any(normalize_text(candidate) in normalized_answer for candidate in candidates)


def load_dataset(path: Path, limit: int | None) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset file not found: {path}. Expected Task 1 data at this path."
        )
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("Dataset must be a JSON list.")
    required = {
        "prompt",
        "target_new",
        "ground_truth",
        "rephrase_prompt",
        "locality_prompt",
        "locality_ground_truth",
    }
    for index, record in enumerate(data, start=1):
        missing = required - set(record)
        if missing:
            raise ValueError(f"Record {index} is missing fields: {sorted(missing)}")
    return data[:limit] if limit else data


def pick_device(device_arg: str) -> torch.device:
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device_arg == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested, but torch.cuda.is_available() is False.")
    return torch.device(device_arg)


def build_prompt(tokenizer: Any, prompt: str, use_chat: bool) -> str:
    if not use_chat:
        return prompt
    messages = [
        {
            "role": "system",
            "content": "Answer as briefly as possible with the name or short phrase only.",
        },
        {"role": "user", "content": prompt},
    ]
    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def generate_answer(
    model: Any,
    tokenizer: Any,
    device: torch.device,
    prompt: str,
    use_chat: bool,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
) -> str:
    model_input = build_prompt(tokenizer, prompt, use_chat)
    encoded = tokenizer(model_input, return_tensors="pt").to(device)
    generation_kwargs: dict[str, Any] = {
        "max_new_tokens": max_new_tokens,
        "pad_token_id": tokenizer.pad_token_id or tokenizer.eos_token_id,
        "eos_token_id": tokenizer.eos_token_id,
    }
    if temperature > 0:
        generation_kwargs.update(
            {
                "do_sample": True,
                "temperature": temperature,
                "top_p": top_p,
            }
        )
    else:
        generation_kwargs.update(
            {
                "do_sample": False,
                "temperature": None,
                "top_p": None,
                "top_k": None,
            }
        )

    with torch.inference_mode():
        output_ids = model.generate(**encoded, **generation_kwargs)
    new_tokens = output_ids[0, encoded["input_ids"].shape[-1] :]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def load_model_and_tokenizer(args: argparse.Namespace, device: torch.device) -> tuple[Any, Any]:
    tokenizer = AutoTokenizer.from_pretrained(
        args.model,
        trust_remote_code=args.trust_remote_code,
    )
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype="auto",
        trust_remote_code=args.trust_remote_code,
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def evaluate_record(
    record: dict[str, Any],
    model: Any,
    tokenizer: Any,
    device: torch.device,
    args: argparse.Namespace,
) -> dict[str, Any]:
    direct_answer = generate_answer(
        model,
        tokenizer,
        device,
        record["prompt"],
        args.chat,
        args.max_new_tokens,
        args.temperature,
        args.top_p,
    )
    rephrase_answer = generate_answer(
        model,
        tokenizer,
        device,
        record["rephrase_prompt"],
        args.chat,
        args.max_new_tokens,
        args.temperature,
        args.top_p,
    )
    locality_answer = generate_answer(
        model,
        tokenizer,
        device,
        record["locality_prompt"],
        args.chat,
        args.max_new_tokens,
        args.temperature,
        args.top_p,
    )

    target_aliases = aliases_for(record, "target_new")
    ground_truth_aliases = aliases_for(record, "ground_truth")
    locality_aliases = aliases_for(record, "locality_ground_truth")

    return {
        **record,
        "direct_answer": direct_answer,
        "rephrase_answer": rephrase_answer,
        "locality_answer": locality_answer,
        "direct_contains_target_new": contains_any(direct_answer, target_aliases),
        "direct_contains_old_ground_truth": contains_any(
            direct_answer, ground_truth_aliases
        ),
        "rephrase_contains_target_new": contains_any(rephrase_answer, target_aliases),
        "locality_contains_ground_truth": contains_any(locality_answer, locality_aliases),
    }


def write_outputs(
    results: list[dict[str, Any]], output_dir: Path, model_name: str
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_model = re.sub(r"[^A-Za-z0-9_.-]+", "_", model_name).strip("_")
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    json_path = output_dir / f"baseline_{safe_model}_{timestamp}.json"
    csv_path = output_dir / f"baseline_{safe_model}_{timestamp}.csv"

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    fieldnames = [
        "prompt",
        "target_new",
        "ground_truth",
        "direct_answer",
        "direct_contains_target_new",
        "direct_contains_old_ground_truth",
        "rephrase_prompt",
        "rephrase_answer",
        "rephrase_contains_target_new",
        "locality_prompt",
        "locality_ground_truth",
        "locality_answer",
        "locality_contains_ground_truth",
        "source",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    return json_path, csv_path


def print_summary(results: list[dict[str, Any]], json_path: Path, csv_path: Path) -> None:
    total = len(results)
    direct_hits = sum(result["direct_contains_target_new"] for result in results)
    old_hits = sum(result["direct_contains_old_ground_truth"] for result in results)
    rephrase_hits = sum(result["rephrase_contains_target_new"] for result in results)
    locality_hits = sum(result["locality_contains_ground_truth"] for result in results)

    print("\nBaseline summary")
    print(f"- Records: {total}")
    print(f"- Direct prompts containing new target: {direct_hits}/{total}")
    print(f"- Direct prompts containing old ground truth: {old_hits}/{total}")
    print(f"- Rephrased prompts containing new target: {rephrase_hits}/{total}")
    print(f"- Locality prompts preserving ground truth: {locality_hits}/{total}")
    print(f"- JSON output: {json_path}")
    print(f"- CSV output: {csv_path}\n")

    for index, result in enumerate(results, start=1):
        print(f"[{index}] {result['prompt']}")
        print(f"    target_new: {result['target_new']}")
        print(f"    old_ground_truth: {result['ground_truth']}")
        print(f"    model_answer: {result['direct_answer']}")


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    args = parse_args()
    if not args.verbose:
        transformers_logging.set_verbosity_error()

    data = load_dataset(args.data, args.limit)
    device = pick_device(args.device)
    print(f"Loading model: {args.model}")
    print(f"Device: {device}")
    print(f"Dataset: {args.data} ({len(data)} records)")

    model, tokenizer = load_model_and_tokenizer(args, device)
    results = [
        evaluate_record(record, model, tokenizer, device, args) for record in data
    ]
    json_path, csv_path = write_outputs(results, args.output_dir, args.model)
    print_summary(results, json_path, csv_path)


if __name__ == "__main__":
    main()
